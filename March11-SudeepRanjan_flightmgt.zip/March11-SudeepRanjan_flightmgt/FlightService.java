package com.example.flightmanagement.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.flightmanagement.dto.FlightDTO;
import com.example.flightmanagement.model.Flight;
import com.example.flightmanagement.repository.FlightRepository;


@Service
public class FlightService {
	@Autowired
	private FlightRepository repository;
	public void addFlight(FlightDTO dto) {
		Flight f = new Flight();
		f.setFlightNumber(dto.getFlightNumber());
		f.setAirlineName(dto.getAirlineName());
		f.setSource(dto.getSource());
		f.setDestination(dto.getDestination());
		f.setPrice(dto.getPrice());
		repository.save(f);
	}
	public List<Flight> viewFlights(){
		return repository.findAll();
	}
	public Flight getFlight(Long id) {
		return repository.findById(id).orElse(null);
	}
	public void updateFlight(Flight flight) {
		repository.save(flight);
	}
	public void deleteFlight(Long id) {
		repository.deleteById(id);
	}
}
