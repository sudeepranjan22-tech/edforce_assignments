package com.example.flightmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.flightmanagement.dto.FlightDTO;
import com.example.flightmanagement.model.Flight;
import com.example.flightmanagement.service.FlightService;

@Controller
public class FlightController {


    @Autowired

    private FlightService service;


    @GetMapping("/addFlight")

    public String addFlightPage() {

        return "addFlight";

    }


    @PostMapping("/saveFlight")

    public String saveFlight(FlightDTO dto) {

        service.addFlight(dto);

        return "redirect:/viewFlights";

    }


    @GetMapping("/viewFlights")

    public String viewFlights(Model model) {

        model.addAttribute("flights", service.viewFlights());

        return "viewFlights";

    }


    @GetMapping("/updateFlight/{id}")

    public String updateFlightPage(@PathVariable Long id, Model model) {

        model.addAttribute("flight", service.getFlight(id));

        return "updateFlight";

    }


    @PostMapping("/updateFlight")

    public String updateFlight(Flight flight) {

        service.updateFlight(flight);

        return "redirect:/viewFlights";

    }


    @GetMapping("/deleteFlight/{id}")

    public String deleteFlight(@PathVariable Long id) {

        service.deleteFlight(id);

        return "redirect:/viewFlights";

    }

}

